
<!-- TOC -->

- [Camunda Spielwiese](#camunda-spielwiese)
    - [Installation der Camunda Plattform und sinnvoller Tools für lokales Arbeiten](#installation-der-camunda-plattform-und-sinnvoller-tools-f%C3%BCr-lokales-arbeiten)
        - [Camunda Plattform hier runterladen:](#camunda-plattform-hier-runterladen)
        - [Camunda Modeler](#camunda-modeler)
        - [VSCode (für Java Developers)](#vscode-f%C3%BCr-java-developers)
        - [Sinnvolle Erweiterungen für VSCode](#sinnvolle-erweiterungen-f%C3%BCr-vscode)
        - [Java Open-JDK 11](#java-open-jdk-11)
        - [Nodejs](#nodejs)
        - [Karate Testdriver](#karate-testdriver)
        - [VSCode Erweiterung für Karate](#vscode-erweiterung-f%C3%BCr-karate)
    - [Eventverarbeitung mit Camunda - Impliziter vs. expliziter Prozessstart](#eventverarbeitung-mit-camunda---impliziter-vs-expliziter-prozessstart)
    - [Modellierung der Events im Processlayer](#modellierung-der-events-im-processlayer)
        - [Variante 1: Explizite Modellierung der Events als Message Entität im Prozess](#variante-1-explizite-modellierung-der-events-als-message-entit%C3%A4t-im-prozess)
    - [Szenarien für die Verarbeitung von Events](#szenarien-f%C3%BCr-die-verarbeitung-von-events)
        - [Szenario 1:  Alle Events kommen unbedingt in der richtigen Reihenfolge.](#szenario-1--alle-events-kommen-unbedingt-in-der-richtigen-reihenfolge)
        - [Szenario 2:  Mittlere Events sind vertauscht, Vertauschung ist nicht relevant.](#szenario-2--mittlere-events-sind-vertauscht-vertauschung-ist-nicht-relevant)
        - [Szenario 3:  Mittlere Events sind vertauscht, Vertauschung nicht relevant.](#szenario-3--mittlere-events-sind-vertauscht-vertauschung-nicht-relevant)
        - [Szenario 4:  Mittlere Events sind vertauscht, Vertauschung relevant.](#szenario-4--mittlere-events-sind-vertauscht-vertauschung-relevant)
        - [Szenario 5:  Mittlere Events sind vertauscht, Event bleibt aus.](#szenario-5--mittlere-events-sind-vertauscht-event-bleibt-aus)
        - [Szenario 6:  Abschlussevent kommt, vor mittleren Events, nicht relevant](#szenario-6--abschlussevent-kommt-vor-mittleren-events-nicht-relevant)
        - [Szenario 7:  Abschlussevent kommt, vor mittleren Events, relevant](#szenario-7--abschlussevent-kommt-vor-mittleren-events-relevant)

<!-- /TOC -->

# Camunda Spielwiese
Alles rund um den Prozesslayer, was nicht direkt so deployed wird!


## Installation der Camunda Plattform und sinnvoller Tools für lokales Arbeiten

### Camunda Plattform hier runterladen:
https://downloads.camunda.cloud/release/camunda-bpm/tomcat/7.13/camunda-bpm-tomcat-7.13.0.zip

Das Archiv enthält alles was zum "Spielen" benötigt wird, also Engine, Web-APPS, Persistenz (h2) und die REST-API. 
Java-/ Script Code kann bei Bedarf einfach im ClassPath des Servers deployed werden, externer Task-Client verbindet sich problemlos per localhost.

### Camunda Modeler
https://downloads.camunda.cloud/release/camunda-modeler/4.0.0/camunda-modeler-4.0.0-win-x64.zip

### VSCode (für Java Developers)
https://code.visualstudio.com/docs/languages/java
Der Download finde sich sich unter 
https://aka.ms/vscode-java-installer-win

Hierbei wird ein VSCode schon für den JAVA-Einsatz vorkonfiguriert. Ansonsten kann man natürlich alle aufgeführten Extensions auch manuell hinzufügen

### Sinnvolle Erweiterungen für VSCode
Git graph zur besseren Visualisierung von Branches
https://marketplace.visualstudio.com/items?itemName=mhutchie.git-graph

markdown-pdf --> Zum Drucken von PDF
https://marketplace.visualstudio.com/items?itemName=yzane.markdown-pdf

REST-Client als Alternative zu SoapUI or whatever. Kann auch Szenarien, aber nicht so mächstig wie Karate.
https://marketplace.visualstudio.com/items?itemName=humao.rest-client

https://marketplace.visualstudio.com/items?itemName=DotJoshJohnson.xml


### Java Open-JDK 11
Keine Ahnung wo das bei der AZ herkommt, aber wir nutzen aktuell 11.04. JAVA_HOME sollte entsprechend gesetzt sein

### Nodejs
https://nodejs.org/en/download/
Wird sowohl für Karate als auch den externen-Task-Client genutzt (letzterer kann allerdings auch in JAVA implementiert werden.)

### Karate Testdriver
Für Karate existieren unterschiedliche Varianten. Im Zusammenspiel mit VSCode wird das Standalone-ZIP benötigt.
Infos dazu:
https://github.com/intuit/karate/releases
https://github.com/intuit/karate/tree/master/karate-netty#standalone-jar
https://github.com/intuit/karate/wiki/ZIP-Release

Das eigentliche Archiv finde sich unter:
https://dl.bintray.com/ptrthomas/karate/

Aktuell sollte da die 0.95-stable genutzt werden

### VSCode Erweiterung für Karate
https://marketplace.visualstudio.com/items?itemName=kirkslota.karate-runner

## Eventverarbeitung mit Camunda - Impliziter vs. expliziter Prozessstart
- Es gibt unterschiedliche Wege in Camunda eine Prozessinstanz zu starten, (explizit oder implizit per Message, Event o.ä.). 
- Der Dispatcher hat die Aufgabe, eingehende Events laufenden Prozessinstanzen zuzuordnen. Daher muss der Dispatcher prüfen, ob zu einem Event eine PI bereits existiert oder existieren kann. Letzteres ist schon eine sehr spezielle Konstellation, bei der ein Folgeevent sicher als "gehört zu einer laufenden Instanz" erkannt werden kann, diese Instanz aber noch nicht auffindbar ist, weil z.B. ein Korrelationsmerkmal eines vorhergehenden Events noch fehlt.
- Trennung von PI-Start und Daten-Einreichung erlaubt imho eine etwas sauberere Modellierung im Dispatcher, weil der Dispatcher keine tiefere Kenntnis von der Bedeutung eines Events haben muss (ausser der Korrelation).
- Sofern ein Event einer PI zugeordnet werden kann, sollte es an die PI übergeben werden.
- Sofern Events in einer PI noch nicht "verarbeitet" werden können, sollten sie im Fachprozess geparkt werden
- Aus Sicht des Dispatchers kann das erste Event im Prozess genauso gehandhabt werden wie alle anderen Events.
- Aber Race-Conditions beachten. Was passiert bei sehr schnellem Event-Eingang? Double-Check Pattern? Oder setzt man darauf, dass nur ein bestimmtes Event eine PI starten kann?


## Modellierung der Events im Processlayer
Für die Modellierunng eingehender Events stehen in Camunda unterschiedliche Möglichkeiten bereit, die je nach Einsatzzweck unterschiedliche Vor- und Nachteile haben.
### Variante 1: Explizite Modellierung der Events als Message Entität im Prozess
An jeder Stelle im Prozess, an der ein Event erwartet wird, wird eine entsprechende Message modelliert. Daraus ergibt sich

## Szenarien für die Verarbeitung von Events
Prämisse ist dabei, dass die Correlation der Events zu PIs erfolgen kann, wenn das nicht der Fall ist, dann bleibt nur ein Parken im Dispatcher übrig.


### Szenario 1:  Alle Events kommen unbedingt in der richtigen Reihenfolge.
Prozess kann dann modelliert werden wie in __model/eventing_1.bpmn__. Beim einreichen neuer Events muss das Ausführungstoken des Prozesses aber immer exakt an der Stelle stehen, an der das entsprechende Event erwartet wird. Findet innerhalb des Prozesses eine zeitfressende Verarbeitung statt, führt das Senden einer neuen Message zu einer Exception im Dispatcher. Die Events müssen dann im Dispatcher auf Halde gelegt werden.

### Szenario 2:  Mittlere Events sind vertauscht, Vertauschung ist nicht relevant.
Events können nicht über 

### Szenario 3:  Mittlere Events sind vertauscht, Vertauschung nicht relevant.

### Szenario 4:  Mittlere Events sind vertauscht, Vertauschung relevant.

### Szenario 5:  Mittlere Events sind vertauscht, Event bleibt aus.

### Szenario 6:  Abschlussevent kommt, vor mittleren Events, nicht relevant

### Szenario 7:  Abschlussevent kommt, vor mittleren Events, relevant
