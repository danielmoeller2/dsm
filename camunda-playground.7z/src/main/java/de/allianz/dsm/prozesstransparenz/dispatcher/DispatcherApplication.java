package de.allianz.dsm.prozesstransparenz.dispatcher;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.servers.Server;
import org.camunda.bpm.application.ProcessApplication;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@OpenAPIDefinition(
        info = @Info(
                title = "DSM-Prozesstransparenz Dispatcher Service",
                description = "Dispatcher Service API documentation",
                version = "0.0.1"
        ),
        servers = {
                @Server(url = "http://localhost:8080",
                        description = "Local Path"),
                @Server(url = "https://dsm-process-dispatcher-service-dcrpi-dsm-pt-dev.apps.dcrpi.azd.cloud.allianz",
                        description = "DEV CRP Path"),
                @Server(url = "https://dsm-process-dispatcher-service-dcrpi-dsm-pt-si.apps.dcrpi.azd.cloud.allianz",
                        description = "SI CRP Path")
        }
)
@ProcessApplication("PT-Dispatcher")
@SpringBootApplication
public class DispatcherApplication {

    public static void main(String[] args) {
        SpringApplication.run(DispatcherApplication.class, args);
    }

}

