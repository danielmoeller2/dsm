package de.allianz.dsm.prozesstransparenz.dispatcher.config;

import de.allianz.dsm.prozesstransparenz.prometheus.HealthMetricsConfiguration;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import({HealthMetricsConfiguration.class})
public class CustomPrometheusConfig {
}
