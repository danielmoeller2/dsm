package de.allianz.dsm.prozesstransparenz.dispatcher.model;

public final class DispatcherProcessVariables {
    private DispatcherProcessVariables(){}

    public static final String BUSINESSPROCESS_TO_START = "processName";
    public static final String IS_INSTANCE_EXISTING = "isInstanceExisting";
}
