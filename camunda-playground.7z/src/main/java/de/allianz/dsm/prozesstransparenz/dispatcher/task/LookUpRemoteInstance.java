package de.allianz.dsm.prozesstransparenz.dispatcher.task;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.camunda.connect.Connectors;
import org.camunda.connect.httpclient.HttpConnector;
import org.camunda.connect.httpclient.HttpResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.logging.Logger;

@Component
public class LookUpRemoteInstance implements JavaDelegate {
    private final Logger log = Logger.getLogger(LookUpRemoteInstance.class.getName());

    @Value("${dispatcher.kdg-remote-url}")
    private String remoteUrl;

    public void execute(DelegateExecution execution) throws Exception {
        callService(remoteUrl);
    }

    public HttpResponse callService(String url){
        //Using build-in http-connector
        HttpConnector http = Connectors.getConnector(HttpConnector.ID);
        HttpResponse response= http.createRequest()
                .get()
                .url(url)
                .execute();

        log.info("\n\n  ... LoggerDelegate invoked by "
                + response.getResponse()
                + " \n\n");

        return response;
    }
}
