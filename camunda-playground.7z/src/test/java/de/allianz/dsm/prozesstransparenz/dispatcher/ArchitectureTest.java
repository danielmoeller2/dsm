package de.allianz.dsm.prozesstransparenz.dispatcher;

import com.tngtech.archunit.core.domain.JavaClasses;
import com.tngtech.archunit.core.importer.ClassFileImporter;
import com.tngtech.archunit.library.GeneralCodingRules;
import com.tngtech.archunit.library.dependencies.SlicesRuleDefinition;
import org.junit.Before;
import org.junit.Test;

public class ArchitectureTest{
    private JavaClasses classes;

    @Before
    public void setUp() throws Exception {
        classes = new ClassFileImporter().importPackages("de.allianz.dsm.camunda");
    }

    @Test
    public void packagesShouldNotHaveCyclicDependencies() {
        SlicesRuleDefinition.slices().matching("de.allianz.dsm.prozesstransparenz.(**)..").should().beFreeOfCycles().check(classes);
        assert(true);
    }

    @Test
    public void doNotUseStandardOutOrStandardError() {
        GeneralCodingRules.NO_CLASSES_SHOULD_ACCESS_STANDARD_STREAMS
                .because("logging (SLF4J) should be used instead")
                .check(classes);
    }

}
