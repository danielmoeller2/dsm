package de.allianz.dsm.prozesstransparenz.dispatcher;

import lombok.extern.slf4j.Slf4j;
import lombok.extern.slf4j.XSlf4j;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.runtime.ProcessInstance;
import org.camunda.bpm.engine.runtime.VariableInstance;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;
import static org.camunda.bpm.extension.mockito.CamundaMockito.autoMock;

import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertTrue;

@Slf4j
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {DispatcherApplication.class})
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_CLASS)
public class DispatcherApplicationTests {

    private static final String PRODUCTION_PROCESS_KEY = "einarbeiter";

    @Autowired
    RuntimeService runtimeService;

    @Test
    public void contextLoads() {
        assertTrue(true);
    }

    @Test
    public void startProductionProcess() throws InterruptedException {
        autoMock("bpmn/einarbeiter.bpmn");

        Map<String, Object> variables = new HashMap<String, Object>();

        String xmlValue = "<?xml version=\"1.0\" encoding=\"UTF-8\"?> <breakfast_menu> <food> <name>Belgian Waffles</name> <price>$5.95</price> <description>Two of our famous Belgian Waffles with plenty of real maple syrup</description> <calories>650</calories> </food> <food> <name>Strawberry Belgian Waffles</name> <price>$7.95</price> <description>Light Belgian waffles covered with strawberries and whipped cream</description> <calories>900</calories> </food> <food> <name>Berry-Berry Belgian Waffles</name> <price>$8.95</price> <description>Light Belgian waffles covered with an assortment of fresh berries and whipped cream</description> <calories>900</calories> </food> <food> <name>French Toast</name> <price>$4.50</price> <description>Thick slices made from our homemade sourdough bread</description> <calories>600</calories> </food> <food> <name>Homestyle Breakfast</name> <price>$6.95</price> <description>Two eggs, bacon or sausage, toast, and our ever-popular hash browns</description> <calories>950</calories> </food> </breakfast_menu>";
        variables.put("rawEvent", xmlValue);

        final ProcessInstance processInstance = runtimeService.startProcessInstanceByKey(PRODUCTION_PROCESS_KEY, variables);
        assertTrue(processInstance != null);
        VariableInstance v =
                runtimeService.createVariableInstanceQuery()
                        .processInstanceIdIn(processInstance.getId())
                        .variableName("rawEvent")
                        .singleResult();

        runtimeService.deleteProcessInstance(processInstance.getId(), "JUnit test");
    }

}
