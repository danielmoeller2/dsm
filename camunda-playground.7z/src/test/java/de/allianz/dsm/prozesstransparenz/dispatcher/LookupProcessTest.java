package de.allianz.dsm.prozesstransparenz.dispatcher;

import de.allianz.dsm.prozesstransparenz.dispatcher.task.LookUpRemoteInstance;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockserver.integration.ClientAndServer;
import org.mockserver.model.Header;
import org.springframework.http.MediaType;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.util.ReflectionTestUtils;

import static io.netty.handler.codec.http.HttpHeaderNames.CONTENT_TYPE;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockserver.character.Character.NEW_LINE;
import static org.mockserver.integration.ClientAndServer.startClientAndServer;
import static org.mockserver.model.HttpRequest.request;
import static org.mockserver.model.HttpResponse.response;

@ExtendWith(MockitoExtension.class)
@TestPropertySource(properties = {"dispatcher.kdg-remote-url=http://localhost:9090"})
public class LookupProcessTest {

    @InjectMocks
    private LookUpRemoteInstance lookUpRemoteInstance;

    @Mock
    private DelegateExecution execution;

    private ClientAndServer mockServer;

    @BeforeEach
    public void startMockServer() {
        ReflectionTestUtils.setField(lookUpRemoteInstance ,"remoteUrl",  "http://localhost:9090");
        mockServer = startClientAndServer(9090);
        mockServer
                .when(
                        request()
                                .withPath("/engine")
                )
                .respond(response()
                        .withHeaders(
                                new Header(CONTENT_TYPE.toString(), MediaType.APPLICATION_JSON_VALUE)
                        )
                        .withBody("" +
                                "[" + NEW_LINE +
                                "    {" + NEW_LINE +
                                "        \"id\": \"1\"," + NEW_LINE +
                                "        \"title\": \"Xenophon's imperial fiction : on the education of Cyrus\"," + NEW_LINE +
                                "        \"author\": \"James Tatum\"," + NEW_LINE +
                                "        \"isbn\": \"0691067570\"," + NEW_LINE +
                                "        \"publicationDate\": \"1989\"" + NEW_LINE +
                                "    }," + NEW_LINE +
                                "    {" + NEW_LINE +
                                "        \"id\": \"2\"," + NEW_LINE +
                                "        \"title\": \"You are here : personal geographies and other maps of the imagination\"," + NEW_LINE +
                                "        \"author\": \"Katharine A. Harmon\"," + NEW_LINE +
                                "        \"isbn\": \"1568984308\"," + NEW_LINE +
                                "        \"publicationDate\": \"2004\"" + NEW_LINE +
                                "    }," + NEW_LINE +
                                "    {" + NEW_LINE +
                                "        \"id\": \"3\"," + NEW_LINE +
                                "        \"title\": \"You just don't understand : women and men in conversation\"," + NEW_LINE +
                                "        \"author\": \"Deborah Tannen\"," + NEW_LINE +
                                "        \"isbn\": \"0345372050\"," + NEW_LINE +
                                "        \"publicationDate\": \"1990\"" + NEW_LINE +
                                "    }" +
                                "]")
                );
    }

    @AfterEach
    public void stopMockServer() {
        mockServer.stop();
    }

    @Test
    public void execute() throws Exception {
        lookUpRemoteInstance.execute(execution);
        assertEquals(200, lookUpRemoteInstance.callService("http://localhost:9090/engine").getStatusCode());
    }


}
