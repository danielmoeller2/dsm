package de.allianz.dsm.prozesstransparenz.dispatcher;

import org.camunda.bpm.engine.runtime.ProcessInstance;
import org.camunda.bpm.engine.test.Deployment;
import org.camunda.bpm.engine.test.mock.Mocks;
import org.camunda.bpm.spring.boot.starter.test.helper.AbstractProcessEngineRuleTest;
import org.junit.Test;

import static org.camunda.bpm.engine.test.assertions.ProcessEngineTests.*;
import static org.camunda.bpm.engine.test.assertions.bpmn.BpmnAwareTests.assertThat;
//import static org.camunda.bpm.extension.mockito.DelegateExpressions.autoMock;
import static org.camunda.bpm.extension.mockito.CamundaMockito.autoMock;
@Deployment(resources = "bpmn/einarbeiter.bpmn")
public class abstractProcessTest extends AbstractProcessEngineRuleTest {

    @Test
    public void eventNotRelevant() {
        autoMock("bpmn/einarbeiter.bpmn");

        final ProcessInstance processInstance = runtimeService().startProcessInstanceByKey("einarbeiter");

        //Looks like this is due to transaction handling. After setting a sync-Point, Process stops after being started

        //for some reason script task are automatically executed ?!
        assertThat(processInstance).hasPassed("initVariables");
        //assertThat(processInstance).isWaitingAt("initVariables");
        //execute(job());

        assertThat(processInstance).isWaitingAt("determineProcessType");
        complete(externalTask());

        assertThat(processInstance).isWaitingAt("determineEventType");
        complete(externalTask());

        assertThat(processInstance).isWaitingAt("Gateway_0enrvjg");
        execute(job());

        assertThat(processInstance).isWaitingAt("dumpToLog");
        complete(externalTask());

        assertThat(processInstance).isEnded();
    }
/*
    @Test
    public void eventRelevantKdg() {
        autoMock("bpmn/einarbeiter.bpmn");

        final ProcessInstance processInstance = runtimeService().startProcessInstanceByKey("einarbeiter");

        //for some reason script task are automatically executed ?!
        assertThat(processInstance).hasPassed("initVariables");
        //assertThat(processInstance).isWaitingAt("initVariables");
        //execute(job());

        assertThat(processInstance).isWaitingAt("determineProcessType");
        complete(externalTask());

        assertThat(processInstance).isWaitingAt("determineEventType");
        complete(externalTask(), withVariables("processType", "kdg"));

        assertThat(processInstance).isWaitingAt("Gateway_0enrvjg");
        execute(job());

        //assertThat(processInstance).isWaitingAt("lookUpPI");
        //complete(externalTask(), withVariables("isInstanceExisting", false));

        assertThat(processInstance).isWaitingAt("gwExistingPI");
        execute(job());

        assertThat(processInstance).isWaitingAt("createPI");
        complete(externalTask());

        assertThat(processInstance).isEnded();
    }

*/

}
