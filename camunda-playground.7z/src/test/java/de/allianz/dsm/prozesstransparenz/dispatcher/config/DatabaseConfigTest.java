package de.allianz.dsm.prozesstransparenz.dispatcher.config;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import javax.sql.DataSource;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

@ExtendWith(MockitoExtension.class)
class DatabaseConfigTest {

    @InjectMocks
    private DatabaseConfig databaseConfig;

    @Mock
    private DataSource dataSource;

    @Test
    void transactionManager_OK() {
        assertNotNull(databaseConfig.transactionManager(dataSource));
    }

    @Test
    void transactionManager_null_FAIL() {
        assertThrows(IllegalArgumentException.class, () -> databaseConfig.transactionManager(null));
    }
}
