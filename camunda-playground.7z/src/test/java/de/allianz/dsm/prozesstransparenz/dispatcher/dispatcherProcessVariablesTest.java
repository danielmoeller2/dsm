package de.allianz.dsm.prozesstransparenz.dispatcher;

import de.allianz.dsm.prozesstransparenz.dispatcher.model.DispatcherProcessVariables;
import org.junit.Test;

import static org.junit.jupiter.api.Assertions.*;

public class dispatcherProcessVariablesTest {

    @Test
    public void checkProcessVariablesConstants() {
        assertNotNull(DispatcherProcessVariables.BUSINESSPROCESS_TO_START);
        assertNotNull(DispatcherProcessVariables.IS_INSTANCE_EXISTING);
    }

}
